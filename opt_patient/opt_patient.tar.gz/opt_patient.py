# -*- coding: utf-8 -*-
from odoo import models, fields, api

class OptPatient(models.Model):
    _name = 'opt.patient'
    # _inherit='spec.referred.by'
    _description='Hospital Patient'

    name = fields.Char('Name', store=True)

    title= fields.Selection(
        [
            ('mr','Mr'),
            ('mrs','Mrs'),
            ('ms','Ms'),
            ('miss','Miss'),
            ('mix','Mx'),
        ],
        default = "mr"
    )
    

    first_name = fields.Char()
    middle_name = fields.Char()
    middle_name = fields.Char()
    last_name = fields.Char()
    suffix = fields.Char()
    
    image_1920 = fields.Binary()


    # Profile 
    # For Left Hand file 

    nick_name = fields.Char(string="Nickname")




    phone = fields.Char('Cell')
    update_label_cell = fields.Boolean("Update")




    other = fields.Char('Other')

    email = fields.Char('Email')

    ## For Address 
    street = fields.Char('Address')
    street2 = fields.Char('Address')
    city = fields.Char("City")
    state_id = fields.Many2one('res.country.state')
    zip = fields.Char("ZIP")
    country_id = fields.Many2one("res.country")
    ## End of Address

    referred_by_id =  fields.Many2one('spec.referred.by')

    date_of_birth = fields.Date(string="Date of Birth")

    ssn = fields.Char(string="SSN")
    
    gender = fields.Selection(
        [
            ('male', 'Male'),
            ('female', 'Female'),
            ('unspecified', 'Unspecified')
        ],
        default = "unspecified"
    )

    gender_identification = fields.Selection(
        [
            ('indentifies_as_male', 'Indentifies as Male'),
            ('indentifies_as_female', 'Indentifies as Female'),
            ('ftm_transgender_male', 'Female-to-Male (FTM)/Transgender Male'),
            ('mtf_transgender_female', 'Male-to-Female (MTF)/ Transgender Female'),
            ('indentifies_confirming_gender', 'Identifies as non-confirming gender'),
            ('additional_gender_category_other', 'Additional gender category or other'),
            ('choose_not_disclose', 'Choose not to disclose')
        ]
    )

    marital_status = fields.Selection(
        [
            ('single', 'Single'),
            ('married', 'Married'),
            ('Divorced', 'Divorced'),
            ('widowed', 'Widowed')
        ],
    )

    occupation = fields.Char(string="Occupation")


    # Profile 
    # For Right Hand file 

    preferred_language = fields.Selection(
        [
            ('declined_to_Specify','Declined to Specify'),
            ('unspecified','Unspecified'),
            ('english','English'),
            ('spanish','Spanish'),
            ('french','French'),
            ('german','German'),
        ]
    )

    race = fields.Selection(
        [
            ('declined','Declined'),
            ('american_indian','American Indian'),
            ('asian','Asian'),
            ('native_pacific_islander','Native Hawaiian or Other Pacific Islander'),
            ('black_or_african_american','Black or African American'),
            ('white','White'),
            ('other','Other'),
        ]
    )

    ethnicity = fields.Selection(
        [
            ('declined_to_Specify','Declined to Specify'),
            ('american_indian_Alaska_native','American Indian or Alaska Native'),
            ('asian','Asian'),
            ('black_or_african_american','Black or African American'),
            ('native_spacific_islander','Native Hawaiian or Other Pacific Islander'),
            ('white','White'),
        ]
    )

    

    partner_id = fields.Many2one('res.partner')

    hipaa_sign = fields.Boolean(string="Signature on file")

    provide = fields.Many2one('hr.employee')

    company_id = fields.Many2one('res.company')

    active = fields.Boolean(string="Active")

    deceased = fields.Boolean(string="Deceased")

    emergency_name = fields.Char(string="Emergency Contact")

    emergency_phone = fields.Char(string="Emergency Phone")

    communication_preferences = fields.Selection(
        [
            ('email','Email'),
            ('phone','Phone'),
            ('cell','Cell')
        ]
    )

    select_all = fields.Boolean(string="Select All")

    # Function for Appointment Smart Button 
    def appointments_list_view(self):
        print("\n\n Appointment Button Called \n\n")
    
    def action_view_partner_invoices(self):
        print("\n\n Invoice Button Called \n\n")
    


    # Adding record in res.partner 


    # @ api.model
    # def create(self, vals):

    #     print("\n\n Called \n\n")

    #     res = super(OptPatient, self).create(vals)
    #     self.env['res.partner'].create(
    #         {
    #             'name':self.first_name,
    #             'image_1920': self.image_1920,
    #             'phone': self.phone,
    #             'email':self.email,
    #         }
    #     )
    #     return res

    communication_ids = fields.One2many(comodel_name = 'spec.communication.table', 'm2o_communication_id')  

    contact_lens_ids = fields.One2many("spec.contact.lenses", 'm2o_spec_contact_lenses')
    
    insurance_id = fields.One2many('my.spec.insurance', 'm2o_spec_insurance')

    documents_ids = fields.One2many('multi.images', 'm2o_multi_images')

    recall_type_ids = fields.One2many('spec.recall.type.line', 'recall')


    # child_ids = fields.One2many('res.partner', 'm2o_res_partner')

    family_ids = fields.Many2many(comodel_name = 'res.partner')  




    

class SpecContactLensesInherit(models.Model):
    _inherit = 'spec.contact.lenses'
    m2o_spec_contact_lenses = fields.Many2one("opt.patient", string='Rx') 


class SpecInsurance(models.Model):
    _name = 'my.spec.insurance'
    _description = 'This is my own spec.insurance'

    name_with_termination_date = fields.Char(string="Insurance", readonly=True)

    sequence = fields.Char(string="Insurance ID")

    termination_date = fields.Date(
        string='Termination',
        default=fields.Date.context_today,
    )
    
    priority = fields.Selection(
        [
            ('primary', 'Primary'),
            ('secondary', 'Secondary'),
            ('tertiary', 'Tertiary'),
        ]
    )

    insurance_type = fields.Selection(
        [
            ('medical', 'Medical'),
            ('vision', 'Vision'),
        ]
    )

    m2o_spec_insurance= fields.Many2one("opt.patient", string='Insurance') 

class MultiImagesInherit(models.Model):
    _inherit = 'multi.images'
    m2o_multi_images= fields.Many2one("opt.patient", string='Documents') 

class SpecRecallTypeLineInherit(models.Model):
    _inherit = 'spec.recall.type.line'

    recall = fields.Many2one('opt.patient')

# class ResPartnerInherit(models.Model):
#     _inherit = 'res.partner'
#     m2o_res_partner = fields.Many2one('opt.patient')


class SpecCommunicationTableInherit(models.Model):
    _inherit = 'spec.communication.table'
    m2o_communication_id = fields.Many2one('opt.patient' string='Communication Table')
